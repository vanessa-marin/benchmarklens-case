# Architecture Overview – BenchmarkLens – SaaS Analytics (EN)
Functional and architecture overview (EN).
