# Learnings – BenchmarkLens – SaaS Analytics (EN)
Key learnings from the project in English.
