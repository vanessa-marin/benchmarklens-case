# PRD – BenchmarkLens – SaaS Analytics (ES)
Requerimientos funcionales y no funcionales en español.
