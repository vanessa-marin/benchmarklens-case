# Metrics – BenchmarkLens – SaaS Analytics (ES)
Métricas clave, NSM y KPIs definidos para el producto.
