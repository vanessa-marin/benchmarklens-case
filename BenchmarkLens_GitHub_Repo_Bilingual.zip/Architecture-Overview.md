# Architecture Overview – BenchmarkLens – SaaS Analytics (ES)
Descripción funcional y de arquitectura (ES).
