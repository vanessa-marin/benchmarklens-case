# PRD – BenchmarkLens – SaaS Analytics (EN)
Functional and non-functional requirements in English.
