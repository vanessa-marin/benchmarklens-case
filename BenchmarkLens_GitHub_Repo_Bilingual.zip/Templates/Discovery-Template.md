# Discovery Template (ES)
